using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace InvoiceTotal
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
          // stting 
            string customerType = txtCustomerType.Text;
            decimal subtotal = Convert.ToDecimal(txtSubtotal.Text);
            decimal discountPercent = .0m;
            // setup the discountPercen for customerType == "R" in different amounts set
            if (customerType == "R")
            {
                if (subtotal < 100)
                    discountPercent = .0m;
                else if (subtotal >= 100 && subtotal < 250)
                    discountPercent = .1m;
                else if (subtotal >= 250 && subtotal < 500)
                    discountPercent = .25m;
                else if (subtotal >= 500 )
                    discountPercent = .30m;      
            }
            // setup the discountPercen for customerType == "T" in different amounts set
            else if (customerType == "T")
            {
                if (subtotal < 500)
                    discountPercent = .40m;
                else if (subtotal >= 500)
                    discountPercent = .50m;
                
                else // customerType Isn't R,T OR C always get %10 percent 
                    discountPercent = .10m;

            }
            // setup the discountPercen for customerType == "C" IF NOT VAILD
            else if (customerType == "C")
            {
                
                discountPercent = .2m;
            }

            // setup the switch and cases of the discountPercen for customerType == "R" "C" "T"in different amounts set
            // basicly copy the code above and addedd to the cases !
            switch (customerType)
            {
                case "R":
                    if (subtotal < 100)
                        discountPercent = .0m;
                    else if (subtotal >= 100 && subtotal < 250)
                        discountPercent = .1m;
                    else if (subtotal >= 250 && subtotal < 500)
                        discountPercent = .25m;
                    else if (subtotal >= 500)
                        discountPercent = .30m;
                    break;
                case "C":
                    discountPercent = .2m;
                    break;
                case "T":
                    if (subtotal < 500)
                        discountPercent = .4m;
                    else if (subtotal >= 500)
                        discountPercent = .5m;
                    break;
                default:
                    discountPercent = .1m;
                    break;
            }

            decimal discountAmount = subtotal * discountPercent;
            decimal invoiceTotal = subtotal - discountAmount;

            txtDiscountPercent.Text = discountPercent.ToString("p1");
            txtDiscountAmount.Text = discountAmount.ToString("c");
            txtTotal.Text = invoiceTotal.ToString("c");

            txtCustomerType.Focus();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            // here is i add some fancy code to the ened of code after fired 
            int i = 0;
            string summaryString = txtTotal.Text;
            for (i = 0; i < 5; i++)
                summaryString += Environment.NewLine;
            
            MessageBox.Show("INVOICE SUMMARY\n\n" + "Your Totals Order for this transection is.\n\n\n\n  "
                + summaryString + "Thank you for your business! \n\n\n" + "Please visit us again!");
            
            this.Close();
        }
    }
}